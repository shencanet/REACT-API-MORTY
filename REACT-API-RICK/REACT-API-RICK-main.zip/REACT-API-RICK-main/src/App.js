import "./App.css";
import Characters from './components/Characters'
import Navbar from "./components/Navbar";
import { useEffect, useState } from "react";
import Pagination from "./components/Pagination";

function App() {
  const [CharacterData, setCharacterData] = useState([]);
  const initialurl = "https://rickandmortyapi.com/api/character";
  const fetchCharacters = (url) => {
    fetch(url)
      .then((response) => response.json())
      .then((data) => setCharacterData(data.results))
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    fetchCharacters(initialurl);
  }, []);

  return (
    <>
      <Navbar brand={"Rick And Morty"} />
      <div className="container mt-5 ">
        <Pagination />
        <Characters CharacterData={CharacterData}/>
        <Pagination />
      </div>
    </>
  );
}

export default App;
